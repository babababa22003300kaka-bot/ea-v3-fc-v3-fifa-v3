# ╔══════════════════════════════════════════════════════════════════════════╗
# ║                🎯 FC26 SELL STATES - حالات بيع الكوينز                  ║
# ║                       Sell Conversation States                          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class SellStates:
    """حالات محادثة بيع الكوينز"""
    CHOOSE_PLATFORM = "choose_platform"
    CHOOSE_TYPE = "choose_type"
    ENTER_AMOUNT = "enter_amount"
    CONFIRM_SALE = "confirm_sale"